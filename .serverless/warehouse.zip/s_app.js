
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'brianjenney',
  applicationName: 'warehouse',
  appUid: 'CqD3J0s1F7nSXd0cg9',
  orgUid: '6740d3c3-527e-4940-9e58-e5cabd43ee67',
  deploymentUid: '0af855a3-d8d5-4d7b-bc05-88d35181b10e',
  serviceName: 'warehouse',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'warehouse-dev-app', timeout: 6 };

try {
  const userHandler = require('./dist/server.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}