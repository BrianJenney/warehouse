
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'brianjenney',
  applicationName: 'warehouse',
  appUid: 'CqD3J0s1F7nSXd0cg9',
  orgUid: '6740d3c3-527e-4940-9e58-e5cabd43ee67',
  deploymentUid: '23930c76-900d-4d8a-9b88-fba0d1878740',
  serviceName: 'warehouse',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'production',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'warehouse-production-app', timeout: 6 };

try {
  const userHandler = require('./dist/server.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}