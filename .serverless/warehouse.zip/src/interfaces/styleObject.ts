export interface StyleObject {
    element: string;
    styles: string[];
    minWidth?: number;
    maxWidth?: number;
}
