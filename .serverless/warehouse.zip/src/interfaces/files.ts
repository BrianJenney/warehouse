export interface UploadedFiles {
    data: Buffer;
    tempFilePath: string;
}
