export interface TokenInterface {
    email?: string;
    name?: string;
}
