import { Router } from 'express';
import { verifyAuthentication } from '../../apiHelpers';
import { createComment } from '../../controllers/comment.controller';

const router = Router();

router.route('/addComment').post(verifyAuthentication, createComment);

export default router;
